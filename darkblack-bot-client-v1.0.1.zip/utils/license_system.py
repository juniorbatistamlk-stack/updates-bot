"""
utils/license_system.py - SISTEMA DE VALIDAÇÃO SIMPLES
Valida chaves de uso único com avisos de expiração
"""
import os
import json
from datetime import datetime, timedelta

LICENSE_FILE = ".license"
LICENSE_DB = "license_database.json"
SUPPORT_CONTACT = "https://t.me/magoTrader_01"

class SimpleLicenseSystem:
    def __init__(self):
        self.is_valid = False
        self.days_left = 0
        self.user_name = ""
        self.license_key = None
    
    def load_local_activation(self):
        """Carrega ativação local (se existe)"""
        if not os.path.exists(LICENSE_FILE):
            return None
        
        try:
            if os.path.getsize(LICENSE_FILE) == 0:
                return None
            
            with open(LICENSE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return None
    
    def save_local_activation(self, key, name, expiry):
        """Salva ativação localmente"""
        data = {
            "key": key,
            "name": name,
            "expiry_date": expiry,
            "activated_at": datetime.now().isoformat()
        }
        
        with open(LICENSE_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    
    def load_database(self):
        """Carrega banco de dados de licenças"""
        if not os.path.exists(LICENSE_DB):
            return {"licenses": []}
        
        try:
            with open(LICENSE_DB, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {"licenses": []}
    
    def save_database(self, db):
        """Salva banco de dados"""
        with open(LICENSE_DB, 'w', encoding='utf-8') as f:
            json.dump(db, f, indent=2, ensure_ascii=False)
    
    def activate_key(self, key):
        """
        Ativa chave (apenas uma vez)
        Returns: (success, message, error_type)
        """
        db = self.load_database()
        
        # Procurar chave no banco
        license_data = None
        for lic in db["licenses"]:
            if lic["key"] == key:
                license_data = lic
                break
        
        if not license_data:
            return False, "❌ Chave inválida! Verifique e tente novamente.", "invalid"
        
        # Verificar se já foi usada
        if license_data["used"]:
            return False, "❌ Esta chave já foi ativada! Cada chave só pode ser usada uma única vez.", "already_used"
        
        # Verificar expiração
        expiry = datetime.fromisoformat(license_data["expiry_date"])
        if expiry < datetime.now():
            return False, f"❌ Esta chave expirou em {expiry.strftime('%d/%m/%Y')}!", "expired"
        
        # Ativar!
        license_data["used"] = True
        license_data["activated_at"] = datetime.now().isoformat()
        self.save_database(db)
        
        # Salvar localmente
        self.save_local_activation(
            key,
            license_data["name"],
            license_data["expiry_date"]
        )
        
        self.is_valid = True
        self.user_name = license_data["name"]
        self.days_left = (expiry - datetime.now()).days
        
        return True, f"✅ Bem-vindo, {license_data['name']}!", "success"
    
    def validate_existing(self):
        """
        Valida ativação existente
        Returns: (is_valid, days_left, warning_type, warning_message)
        """
        activation = self.load_local_activation()
        
        if not activation:
            return False, 0, None, None
        
        expiry = datetime.fromisoformat(activation["expiry_date"])
        days_left = (expiry - datetime.now()).days
        
        self.user_name = activation["name"]
        self.license_key = activation["key"]
        self.days_left = days_left
        
        # Expirado
        if days_left < 0:
            self.is_valid = False
            return False, days_left, "expired", self._get_expired_message()
        
        # Expirando em breve (3 dias ou menos)
        if days_left <= 3:
            self.is_valid = True
            return True, days_left, "expiring", self._get_expiring_message(days_left)
        
        # OK
        self.is_valid = True
        return True, days_left, None, None
    
    def _get_expiring_message(self, days):
        """Mensagem de aviso - expirando"""
        if days == 0:
            dias_str = "HOJE"
        elif days == 1:
            dias_str = "AMANHÃ"
        else:
            dias_str = f"em {days} dias"
        
        return (
            f"⚠️ [bold yellow]ATENÇÃO: Sua licença expira {dias_str}![/bold yellow]\n\n"
            f"💬 Entre em contato para renovar e continuar faturando:\n"
            f"[bold cyan]{SUPPORT_CONTACT}[/bold cyan]\n\n"
            f"[dim]Não perca acesso ao melhor bot de trading! 🚀[/dim]"
        )
    
    def _get_expired_message(self):
        """Mensagem de aviso - expirado"""
        return (
            f"🚨 [bold red]SUA LICENÇA EXPIROU![/bold red]\n\n"
            f"💰 Renove agora e volte a lucrar no automático:\n"
            f"[bold cyan]{SUPPORT_CONTACT}[/bold cyan]\n\n"
            f"[dim]Continue operando com o Dark Black Bot PRO! 💎[/dim]"
        )
    
    def is_first_run(self):
        """Verifica se é primeira execução"""
        return not os.path.exists(LICENSE_FILE)

def check_license():
    """
    Função principal de verificação
    Returns: (success, license_system, message)
    """
    from rich.console import Console
    from rich.prompt import Prompt
    from rich.panel import Panel
    
    console = Console()
    lic = SimpleLicenseSystem()
    
    # Primeira execução - pedir chave
    if lic.is_first_run():
        console.print(Panel(
            "[bold bright_cyan]🔐 DARK BLACK BOT PRO - ATIVAÇÃO[/bold bright_cyan]\n\n"
            "[white]Bem-vindo! Para começar, ative sua licença.[/white]\n\n"
            "[yellow]Insira sua chave de ativação:[/yellow]\n\n"
            "[dim]⚠️ IMPORTANTE: Cada chave só pode ser usada UMA ÚNICA VEZ[/dim]\n"
            "[dim]Após ativação, sua licença ficará vinculada a este computador.[/dim]",
            border_style="bright_cyan",
            title="Ativação"
        ))
        
        key = Prompt.ask("\n[bold]Chave de Licença[/bold]").strip().upper()
        
        success, message, error_type = lic.activate_key(key)
        
        if not success:
            console.print(f"\n{message}")
            console.print(f"\n[yellow]Precisa de ajuda? Entre em contato:[/yellow]")
            console.print(f"[cyan]{SUPPORT_CONTACT}[/cyan]\n")
            return False, lic, message
        
        console.print(f"\n{message}")
        console.print(f"[green]🎉 Licença ativada com sucesso![/green]\n")
        
        # Verificar se já está expirando
        valid, days, warn_type, warn_msg = lic.validate_existing()
        if warn_type and warn_msg:
            console.print(Panel(warn_msg, border_style="yellow" if warn_type == "expiring" else "red"))
        
        return True, lic, "Ativado"
    
    # Já ativado - validar
    valid, days, warn_type, warn_msg = lic.validate_existing()
    
    if not valid:
        # Expirado
        console.print(Panel(warn_msg, border_style="red", title="⚠️ Licença Expirada"))
        return False, lic, "Expirado"
    
    # Válido - mostrar avisos se necessário
    if warn_type == "expiring":
        console.print(Panel(warn_msg, border_style="yellow", title="⚠️ Aviso de Expiração"))
    
    # Mensagem de boas-vindas
    if days > 3:
        console.print(f"[green]✅ Licença ativa[/green] | [dim]{lic.user_name} - {days} dias restantes[/dim]")
    
    return True, lic, "OK"
