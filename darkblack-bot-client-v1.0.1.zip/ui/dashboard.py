# ui/dashboard.py
from rich.console import Console
from rich.layout import Layout
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.live import Live
from rich.align import Align
from rich.style import Style
from rich import box
from datetime import datetime

class Dashboard:
    def __init__(self, config):
        self.console = Console()
        self.config = config
        self.logs = []
        self.system_logs = []  # Logs do sistema (IA, IQ, etc)
        
        # Contadores para agrupar mensagens repetitivas
        self._preanalysis_count = 0
        self._timeout_count = 0
        self._reconnect_count = 0
        self._last_summary_time = 0
        
        # Create layout structure ONCE
        self.layout = Layout()
        self.layout.split_column(
            Layout(name="header", size=10),
            Layout(name="stats", size=10),
            Layout(name="bottom")
        )
        
        # Split bottom into two panels
        self.layout["bottom"].split_row(
            Layout(name="operations"),
            Layout(name="system")
        )

    def log(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        # FILTRO ULTRA-AGRESSIVO: Mostrar APENAS o essencial
        
        # Silenciar completamente (ruído)
        if any(noise in message for noise in [
            "Pré-análise", "Dados insuficientes", "TIMEOUT", 
            "Reconectando", "Reconectado", "tentativa",
            "Analisando", "timeouts detectados"
        ]):
            return  # Não mostrar nada
        
        # Silenciar logs de estratégia repetitivos
        if "[STRATEGY]" in message:
            # Mostrar APENAS resultados finais (resistências/suportes)
            if "resistências" in message or "suportes" in message:
                # Compactar: remover emoji e timestamp redundante
                clean_msg = message.replace("📊", "").replace("✅", "").strip()
                self.system_logs.append(f"[{timestamp}] {clean_msg}")
                if len(self.system_logs) > 8:  # Apenas 8 linhas
                    self.system_logs.pop(0)
            return
        
        # Logs de IA: Apenas confirmações e rejeições
        if "[AI]" in message:
            if any(keyword in message for keyword in ["Confirmado", "Rejeitado", "Evitando"]):
                # Compactar mensagem
                clean_msg = message.replace("🤖", "").replace("⚠️", "⚠").strip()
                self.system_logs.append(f"[{timestamp}] {clean_msg}")
                if len(self.system_logs) > 8:
                    self.system_logs.pop(0)
            return
        
        # Logs de IQ_HANDLER: Apenas falhas totais
        if "[IQ_HANDLER]" in message:
            if "Falha total" in message or "❌" in message:
                self.system_logs.append(f"[{timestamp}] {message}")
                if len(self.system_logs) > 8:
                    self.system_logs.pop(0)
            return
        
        # Histórico de operações: Tudo (sinais, trades, resultados)
        self.logs.append(f"[{timestamp}] {message}")
        if len(self.logs) > 12:  # Reduzido para 12
            self.logs.pop(0)

    def generate_header(self):
        # Premium Cyberpunk ASCII Art Banner - Cyan/White theme
        banner = """
[bold bright_cyan]╔══════════════════════════════════════════════════════════════════════════════════╗[/bold bright_cyan]
[bold bright_cyan]║[/bold bright_cyan]   [bold bright_white]██████╗  █████╗ ██████╗ ██╗  ██╗    ██████╗ ██╗      █████╗  ██████╗██╗  ██╗[/bold bright_white]   [bold bright_cyan]║[/bold bright_cyan]
[bold bright_cyan]║[/bold bright_cyan]   [bold bright_white]██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝    ██╔══██╗██║     ██╔══██╗██╔════╝██║ ██╔╝[/bold bright_white]   [bold bright_cyan]║[/bold bright_cyan]
[bold bright_cyan]║[/bold bright_cyan]   [bold bright_white]██║  ██║███████║██████╔╝█████╔╝     ██████╔╝██║     ███████║██║     █████╔╝ [/bold bright_white]   [bold bright_cyan]║[/bold bright_cyan]
[bold bright_cyan]║[/bold bright_cyan]   [bold bright_white]██║  ██║██╔══██║██╔══██╗██╔═██╗     ██╔══██╗██║     ██╔══██║██║     ██╔═██╗ [/bold bright_white]   [bold bright_cyan]║[/bold bright_cyan]
[bold bright_cyan]║[/bold bright_cyan]   [bold bright_white]██████╔╝██║  ██║██║  ██║██║  ██╗    ██████╔╝███████╗██║  ██║╚██████╗██║  ██╗[/bold bright_white]   [bold bright_cyan]║[/bold bright_cyan]
[bold bright_cyan]║[/bold bright_cyan]   [bold bright_white]╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝[/bold bright_white]   [bold bright_cyan]║[/bold bright_cyan]
[bold bright_cyan]║[/bold bright_cyan]       [bold bright_yellow]⚡ PRO TRADING SYSTEM v3.0[/bold bright_yellow]  [dim]│[/dim]  [bold bright_green]● ONLINE[/bold bright_green]  [dim]│[/dim]  [bold bright_cyan]🔥 ATIVO[/bold bright_cyan]         [bold bright_cyan]║[/bold bright_cyan]
[bold bright_cyan]╚══════════════════════════════════════════════════════════════════════════════════╝[/bold bright_cyan]
"""
        return Align.center(banner)

    def generate_stats_table(self, current_profit, time_to_close):
        profit_color = "bright_green" if current_profit >= 0 else "bright_red"
        timer_color = "bright_yellow" if time_to_close > 10 else "bright_red"
        
        # Create Advanced Stats Grid
        table = Table.grid(expand=True, padding=(0, 3))
        table.add_column("Col1", ratio=1)
        table.add_column("Col2", ratio=1)
        table.add_column("Col3", ratio=1)
        
        # Row 1: Sistema
        table.add_row(
            f"[bold bright_cyan]▸ ESTRATÉGIA[/bold bright_cyan]\n  [white]{self.config.strategy_name}[/white]",
            f"[bold bright_cyan]▸ PARIDADE[/bold bright_cyan]\n  [bright_yellow]{self.config.asset}[/bright_yellow] [dim]│ M{self.config.timeframe}[/dim]",
            f"[bold bright_cyan]▸ STATUS[/bold bright_cyan]\n  [bright_green]● ATIVO[/bright_green]"
        )
        
        # Separator
        table.add_row("\n" + "─" * 20, "\n" + "─" * 20, "\n" + "─" * 20)
        
        # Row 2: Financeiro
        balance_icon = "💰"
        profit_icon = "🔺" if current_profit >= 0 else "🔻"
        
        # Calcular tempo da vela em formato MM:SS
        candle_total_seconds = self.config.timeframe * 60
        mins_elapsed = int(time_to_close) // 60
        secs_elapsed = int(time_to_close) % 60
        time_display = f"{mins_elapsed}:{secs_elapsed:02d}"
        total_display = f"{self.config.timeframe}m"
        
        table.add_row(
            f"[bold bright_cyan]▸ SALDO[/bold bright_cyan]\n  {balance_icon} [bright_white]R$ {self.config.balance:.2f}[/bright_white]",
            f"[bold bright_cyan]▸ LUCRO/PERDA[/bold bright_cyan]\n  {profit_icon} [bold {profit_color}]R$ {current_profit:+.2f}[/bold {profit_color}]",
            f"[bold bright_cyan]▸ TEMPO VELA[/bold bright_cyan]\n  ⏱️  [{timer_color}]{time_display}[/] [dim]/ {total_display}[/dim]"
        )
        
        # Meta Row
        profit_goal = getattr(self.config, 'profit_goal', 0) or 0
        if profit_goal > 0:
            goal_progress = (current_profit / profit_goal * 100) if profit_goal > 0 else 0
            goal_progress = min(goal_progress, 100)  # Cap at 100%
            
            # Progress bar
            bar_width = 20
            filled = int((goal_progress / 100) * bar_width)
            bar = "█" * filled + "░" * (bar_width - filled)
            
            goal_color = "bright_green" if goal_progress >= 100 else "bright_yellow" if goal_progress >= 50 else "bright_blue"
            remaining = max(0, profit_goal - current_profit)
            
            table.add_row("\n" + "─" * 20, "\n" + "─" * 20, "\n" + "─" * 20)
            table.add_row(
                f"[bold bright_cyan]▸ META DIÁRIA[/bold bright_cyan]\n  🎯 [bright_white]R$ {profit_goal:.2f}[/bright_white]",
                f"[bold bright_cyan]▸ PROGRESSO[/bold bright_cyan]\n  [{goal_color}]{bar}[/{goal_color}] [bold {goal_color}]{goal_progress:.0f}%[/bold {goal_color}]",
                f"[bold bright_cyan]▸ RESTANTE[/bold bright_cyan]\n  📊 [bright_white]R$ {remaining:.2f}[/bright_white]"
            )
        
        return Panel(
            table,
            title="[bold bright_cyan]╡ PAINEL DE CONTROLE ╞[/bold bright_cyan]",
            border_style="bright_cyan",
            box=box.DOUBLE
        )

    def generate_operations_log(self):
        """Painel esquerdo - Histórico de operações"""
        if not self.logs:
            log_content = "[dim]Aguardando operações...[/dim]"
        else:
            formatted_logs = []
            for log in self.logs[-25:]:
                if "WIN" in log or "✅" in log:
                    formatted_logs.append(f"[bright_green]►[/bright_green] {log}")
                elif "LOSS" in log or "❌" in log:
                    formatted_logs.append(f"[bright_red]►[/bright_red] {log}")
                elif "SINAL" in log or "🎯" in log or "DISPARANDO" in log:
                    formatted_logs.append(f"[bright_yellow]►[/bright_yellow] {log}")
                elif "GALE" in log:
                    formatted_logs.append(f"[bright_magenta]►[/bright_magenta] {log}")
                else:
                    formatted_logs.append(f"[dim]►[/dim] {log}")
            log_content = "\n".join(formatted_logs)
        
        return Panel(
            log_content, 
            title="[bold bright_green]╡ 📊 HISTÓRICO DE OPERAÇÕES ╞[/bold bright_green]", 
            border_style="bright_green",
            box=box.ROUNDED
        )

    def generate_system_log(self):
        """Painel direito - Logs do sistema (IA, IQ, etc)"""
        if not self.system_logs:
            log_content = "[dim]Sistema inicializando...[/dim]"
        else:
            formatted_logs = []
            for log in self.system_logs[-8:]:
                if "[AI]" in log:
                    if "✅" in log or "Confirmado" in log:
                        formatted_logs.append(f"[bright_green]🤖[/bright_green] {log}")
                    elif "❌" in log or "Rejeitado" in log:
                        formatted_logs.append(f"[bright_red]🤖[/bright_red] {log}")
                    else:
                        formatted_logs.append(f"[bright_magenta]🤖[/bright_magenta] {log}")
                elif "[IQ]" in log:
                    if "Sucesso" in log:
                        formatted_logs.append(f"[bright_green]📡[/bright_green] {log}")
                    else:
                        formatted_logs.append(f"[bright_cyan]📡[/bright_cyan] {log}")
                else:
                    formatted_logs.append(f"[dim]⚙️[/dim] {log}")
            log_content = "\n".join(formatted_logs)
        
        return Panel(
            log_content, 
            title="[bold bright_magenta]╡ 🤖 SISTEMA & IA ╞[/bold bright_magenta]", 
            border_style="bright_magenta",
            box=box.ROUNDED
        )

    def render(self, current_profit, time_to_close=0):
        self.layout["header"].update(self.generate_header())
        self.layout["stats"].update(self.generate_stats_table(current_profit, time_to_close))
        self.layout["operations"].update(self.generate_operations_log())
        self.layout["system"].update(self.generate_system_log())
        return self.layout
